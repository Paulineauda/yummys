
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

declare var bootstrap: any;

@Component({
  selector: 'app-reserver-table',
  templateUrl: './reserver-table.component.html',
  styleUrls: ['./reserver-table.component.scss']
})
export class ReserverTableComponent {
  reservationForm: FormGroup;

  constructor(private fb: FormBuilder, private router: Router) { // Injectez Router
    this.reservationForm = this.fb.group({
      nom: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      date: ['', Validators.required],
      heure: ['', Validators.required],
      nombrePersonnes: ['', Validators.required]
    });
  }


  onSubmit() {
    if (this.reservationForm.valid) {
      console.log('Réservation envoyée', this.reservationForm.value);
      // Ici, vous pouvez ajouter le code pour envoyer le formulaire au serveur

      // Affichez la fenêtre d'alerte
      window.alert("Votre réservation est confirmée.");

      // Redirigez l'utilisateur vers l'accueil
      this.router.navigate(['/']);  // Supposant que '/' est votre route d'accueil
    }
  }
}







