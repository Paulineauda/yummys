import { Component, OnInit } from '@angular/core';
import { PlatService } from 'src/app/plat/plat.service';
import { Plat } from 'src/app/plat/plat.model';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {
  plats!: Plat[];

  constructor(private platService: PlatService) { }

  ngOnInit(): void {
    this.plats = this.platService.getPlats();
  }
}


